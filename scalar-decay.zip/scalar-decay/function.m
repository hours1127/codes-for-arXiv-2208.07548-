(* ::Package:: *)

(* ::InheritFromParent::Initialization:: *)
(*(**)*)


couplingsn[\[Phi]np_]:=Block[{},
{wn=\[Phi]np^2 \[Eta]/8,
vpn=0(\[Phi]np),
vpdn=0(\[Phi]np),
w1n=\[Phi]np \[Eta]/4,
w2n=Table[\[Eta]/4,{i,1,nx-(exc-1)}]}]


(*part one\:ff0c solve constraints*)


(*equation for A zeta+B zeta^2+C zeta1n+D \[Equal]0*)
t0L[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=-(1/4) Pnf Qnf rnf^(3/2)+(-(3/8) Pnf Sqrt[rnf] w1nf-1/4 P1nf rnf^(3/2) w1nf-1/4 Pnf Qnf rnf^(3/2) w2nf-1/8 Pnf Qnf rnf^(3/2) wnf) \[Beta]c+(-(1/8) Pnf Qnf rnf^(3/2) w1nf^2-3/16 Pnf Sqrt[rnf] w1nf wnf-1/8 P1nf rnf^(3/2) w1nf wnf-1/8 Pnf Qnf rnf^(3/2) w2nf wnf) \[Beta]c^2+\[Alpha]c (-(1/2) Pnf^3 Sqrt[rnf] w1nf-3/2 Pnf Qnf^2 Sqrt[rnf] w1nf-Pnf Sqrt[rnf] vpnf w1nf+(-((7 Pnf Qnf w1nf^2)/(2 Sqrt[rnf]))-Pnf Q1nf Sqrt[rnf] w1nf^2-P1nf Qnf Sqrt[rnf] w1nf^2-2 Pnf Qnf^2 Sqrt[rnf] w1nf w2nf) \[Beta]c)

tm1L[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=(-(1/8) Pnf^2 rnf^2-(Qnf^2 rnf^2)/8-(rnf^2 vpnf)/4+(-(1/2) Qnf rnf w1nf-1/4 Q1nf rnf^2 w1nf+1/32 Pnf^2 Qnf rnf^3 w1nf-1/32 Qnf^3 rnf^3 w1nf-1/16 Qnf rnf^3 vpnf w1nf-1/4 Qnf^2 rnf^2 w2nf-1/16 Pnf^2 rnf^2 wnf-1/16 Qnf^2 rnf^2 wnf-1/8 rnf^2 vpnf wnf) \[Beta]c+(-(1/8) Qnf^2 rnf^2 w1nf^2+1/16 P1nf Pnf rnf^3 w1nf^2-1/16 Q1nf Qnf rnf^3 w1nf^2+1/16 Pnf^2 Qnf rnf^3 w1nf w2nf-1/16 Qnf^3 rnf^3 w1nf w2nf-1/4 Qnf rnf w1nf wnf-1/8 Q1nf rnf^2 w1nf wnf-1/8 Qnf^2 rnf^2 w2nf wnf) \[Beta]c^2+\[Alpha]c (-(1/2) Pnf^2 Qnf rnf w1nf-1/2 Qnf^3 rnf w1nf-Qnf rnf vpnf w1nf+(-2 Qnf^2 w1nf^2-Q1nf Qnf rnf w1nf^2-Qnf^3 rnf w1nf w2nf) \[Beta]c))

t1L[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=((-((8 Qnf^2 w1nf^2)/rnf^3)+(8 Q1nf Qnf w1nf^2)/rnf^2+(8 Qnf^3 w1nf w2nf)/rnf^2) \[Alpha]c^2+(Qnf w1nf \[Beta]c)/8+1/16 Qnf w1nf wnf \[Beta]c^2+\[Alpha]c (-(5/4) Pnf^2 Qnf w1nf+(Qnf^3 w1nf)/4-(2 Qnf w1nf)/rnf^2+(2 Q1nf w1nf)/rnf+(Qnf vpnf w1nf)/2+(2 Qnf^2 w2nf)/rnf+(-2 P1nf Pnf w1nf^2+Q1nf Qnf w1nf^2-(3 Pnf^2 w1nf^2)/(2 rnf)+(Qnf^2 w1nf^2)/rnf-2 Pnf^2 Qnf w1nf w2nf+Qnf^3 w1nf w2nf-(Qnf w1nf wnf)/rnf^2+(Q1nf w1nf wnf)/rnf+(Qnf^2 w2nf wnf)/rnf) \[Beta]c)) 

t2L[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=((-((20 Pnf Qnf w1nf^2)/rnf^(7/2))+(8 Pnf Q1nf w1nf^2)/rnf^(5/2)+(8 P1nf Qnf w1nf^2)/rnf^(5/2)+(16 Pnf Qnf^2 w1nf w2nf)/rnf^(5/2)) \[Alpha]c^2+\[Alpha]c (-((3 Pnf w1nf)/rnf^(5/2))+(2 P1nf w1nf)/rnf^(3/2)+(2 Pnf Qnf w2nf)/rnf^(3/2)+((Pnf Qnf w1nf^2)/rnf^(3/2)-(3 Pnf w1nf wnf)/(2 rnf^(5/2))+(P1nf w1nf wnf)/rnf^(3/2)+(Pnf Qnf w2nf wnf)/rnf^(3/2)) \[Beta]c))

t3L[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=((-((12 Pnf^2 w1nf^2)/rnf^4)+(12 P1nf Pnf w1nf^2)/rnf^3-(4 Q1nf Qnf w1nf^2)/rnf^3+(12 Pnf^2 Qnf w1nf w2nf)/rnf^3-(4 Qnf^3 w1nf w2nf)/rnf^3) \[Alpha]c^2+\[Alpha]c (-((Qnf w1nf)/rnf^3)-(Qnf w1nf wnf \[Beta]c)/(2 rnf^3))) 

t20L[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Phi]nf_]:=1+(16 Qnf^2 w1nf^2 \[Alpha]c^2)/rnf^2+wnf \[Beta]c+(wnf^2 \[Beta]c^2)/4+\[Alpha]c ((8 Qnf w1nf)/rnf+(-Pnf^2 w1nf^2+(4 Qnf w1nf wnf)/rnf) \[Beta]c)
t21L[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Phi]nf_]:=((40 Pnf Qnf w1nf^2 \[Alpha]c^2)/rnf^(5/2)+\[Alpha]c ((10 Pnf w1nf)/rnf^(3/2)+(5 Pnf w1nf wnf \[Beta]c)/rnf^(3/2)))
t22L[Pnf_,rnf_,w1nf_,\[Phi]nf_]:=(24 (Pnf^2) (w1nf^2) (\[Alpha]c^2) )/rnf^3
t2m1[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Phi]nf_]:=-(1/4) Pnf rnf^(3/2) w1nf \[Beta]c-Pnf Qnf Sqrt[rnf] w1nf^2 \[Alpha]c \[Beta]c-1/8 Pnf rnf^(3/2) w1nf wnf \[Beta]c^2
term1L[t0c_,t1Lc_,t2Lc_,t3Lc_,tm1c_,\[Zeta]fnt_]:=t0c+tm1c/\[Zeta]fnt+(t1Lc+t2Lc \[Zeta]fnt+t3Lc \[Zeta]fnt^2)\[Zeta]fnt;
term2L[t20_,t21_,t22_,t2m1_,\[Zeta]n_]:=t20+t21 \[Zeta]n+t22 \[Zeta]n^2+t2m1/\[Zeta]n


initialzealsolvers2ndorder[drm1hp_,Pnf_,Qnf_,rn1d2f_,vpnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=
Block[{
pnh=(Pnf[[1;;-2]]+Pnf[[2;;-1]])/2.,
p1nh=(Pnf[[2;;-1]]-Pnf[[1;;-2]])drm1hp,
qnh=(Qnf[[1;;-2]]+Qnf[[2;;-1]])/2.,
q1nh=(Qnf[[2;;-1]]-Qnf[[1;;-2]])drm1hp,
\[Phi]nh=(\[Phi]nf[[1;;-2]]+\[Phi]nf[[2;;-1]])/2.,
wnh=\[Phi]nh^2 \[Eta]/8,
vpnh=0(\[Phi]nh),
vpdnh=0(\[Phi]nh),
w1nh=\[Phi]nh \[Eta]/4,
w2nh=Table[\[Eta]/4.,{i,1,nx-1-(exc-1)}]
},
{initialzetasolver2ndorder[drm1hp,pnh,p1nh,qnh,q1nh,rn1d2f,vpnh,wnh,w1nh,w2nh,\[Phi]nh],
alphasolver2ndorder[drm1hp,pnh,p1nh,qnh,rn1d2f,wnh,w1nh,w2nh,\[Phi]nh,\[Zeta]n]}]


initialmatrixJ2ndorder[drm1hp_,\[Zeta]nhp_,\[Zeta]1nhp_,t0Lf_,t1Lf_,t2Lf_,t3Lf_,t20Lf_,t21Lf_,t22Lf_,t2m1f_]:=
Block[{\[Zeta]nh2s,\[Zeta]nh2srev,b1,b2,b3,allb1b2},
\[Zeta]nh2s=\[Zeta]nhp^2;
\[Zeta]nh2srev=1/\[Zeta]nh2s;
b1=(t1Lf+2t2Lf \[Zeta]nhp+3t3Lf \[Zeta]nh2s-t0Lf \[Zeta]nh2srev)/2.;(*term1L\:5bf9\[Zeta]fnt\:7684\:5bfc\:6570*)
b2=(t21Lf+2t22Lf \[Zeta]nhp-t2m1f \[Zeta]nh2srev)\[Zeta]1nhp/2.;                           (*term2L\:5bf9\[Zeta]fnt\:7684\:5bfc\:6570*)
b3=term2L[t20Lf,t21Lf,t22Lf,t2m1f,\[Zeta]nhp]drm1hp;(*term2L\:4f5c\:4e3a\:7cfb\:6570\:ff0c\:5bfc\:51fd\:6570\:5bf9\[Zeta]fnt\:7684\:5bfc\:6570*)
allb1b2=b1+b2;
initialmatrixJ2nd=SparseArray[{
Band[{1,1}]->allb1b2+b3,
Band[{2,1}]->allb1b2[[2;;-1]]-b3[[2;;-1]]                    
},
{nx-1-(exc-1),nx-1-(exc-1)}];]


initialzetasolver2ndorder[drm1hp_,pnhp_,p1nhp_,qnhp_,q1nhp_,rn1d2p_,vpnhp_,wnhp_,w1nhp_,w2nhp_,\[Phi]nhp_]:=
Block[{aa,err=0,errTol=10^-14,MG,\[Delta]M,matrixJ2nd,\[Zeta]1nh,\[Zeta]nh,
t0Lp=t0L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
tm1Lp=tm1L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t1Lp=t1L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t2Lp=t2L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t3Lp=t3L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t20Lp=t20L[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp],
t21Lp=t21L[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp],
t22Lp=t22L[pnhp,rn1d2p,w1nhp,\[Phi]nhp],
t2m1p=t2m1[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp]
},
{Do[{
\[Zeta]1nh=(\[Zeta]n[[2;;-1]]-\[Zeta]n[[1;;-2]])drm1hp;
\[Zeta]nh=(\[Zeta]n[[2;;-1]]+\[Zeta]n[[1;;-2]])/2.;
MG=term1L[t0Lp,t1Lp,t2Lp,t3Lp,tm1Lp,\[Zeta]nh]+term2L[t20Lp,t21Lp,t22Lp,t2m1p,\[Zeta]nh]\[Zeta]1nh;
initialmatrixJ2ndorder[drm1hp,\[Zeta]nh,\[Zeta]1nh,t0Lp,t1Lp,t2Lp,t3Lp,t20Lp,t21Lp,t22Lp,t2m1p];

\[Delta]M=LinearSolve[initialmatrixJ2nd,-MG];
\[Zeta]n=Join[{\[Zeta]boun},\[Zeta]n[[2;;-1]]+\[Delta]M];
err+=Total[Abs[\[Delta]M]];
err/=(nx-exc);
(*Print[{aa,err}];*)
If[err<errTol,Break[]];
},{aa,1,300}
];
\[Zeta]1n=connection[\[Zeta]n];}
]


zealsolvers2ndorder[drm1hp_,Pnf_,Qnf_,rn1d2f_,vpnf_,wnf_,w1nf_,w2nf_,\[Phi]nf_]:=
Block[{
pnh=(Pnf[[1;;-2]]+Pnf[[2;;-1]])/2.,
p1nh=(Pnf[[2;;-1]]-Pnf[[1;;-2]])drm1hp,
qnh=(Qnf[[1;;-2]]+Qnf[[2;;-1]])/2.,
q1nh=(Qnf[[2;;-1]]-Qnf[[1;;-2]])drm1hp,
\[Phi]nh=(\[Phi]nf[[1;;-2]]+\[Phi]nf[[2;;-1]])/2.,
wnh=\[Phi]nh^2 \[Eta]/8,
vpnh=0(\[Phi]nh),
vpdnh=0(\[Phi]nh),
w1nh=\[Phi]nh \[Eta]/4,
w2nh=Table[\[Eta]/4.,{i,1,nx-1-(exc-1)}]
},
{zetasolver2ndorder[drm1hp,pnh,p1nh,qnh,q1nh,rn1d2f,vpnh,wnh,w1nh,w2nh,\[Phi]nh],
alphasolver2ndorder[drm1hp,pnh,p1nh,qnh,rn1d2f,wnh,w1nh,w2nh,\[Phi]nh,\[Zeta]n]}]


zetasolver2ndorder[drm1hp_,pnhp_,p1nhp_,qnhp_,q1nhp_,rn1d2p_,vpnhp_,wnhp_,w1nhp_,w2nhp_,\[Phi]nhp_]:=
Block[{aa,err=0,errTol=10^-14,MG,\[Delta]M,matrixJ2nd,\[Zeta]1nh,\[Zeta]nh,
t0Lp=t0L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
tm1Lp=tm1L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t1Lp=t1L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,vpnhp,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t2Lp=t2L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t3Lp=t3L[pnhp,p1nhp,qnhp,q1nhp,rn1d2p,wnhp,w1nhp,w2nhp,\[Phi]nhp],
t20Lp=t20L[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp],
t21Lp=t21L[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp],
t22Lp=t22L[pnhp,rn1d2p,w1nhp,\[Phi]nhp],
t2m1p=t2m1[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp]

},
{Do[{
\[Zeta]1nh=(\[Zeta]n[[2;;-1]]-\[Zeta]n[[1;;-2]])drm1hp;
\[Zeta]nh=(\[Zeta]n[[2;;-1]]+\[Zeta]n[[1;;-2]])/2.;
MG=term1L[t0Lp,t1Lp,t2Lp,t3Lp,tm1Lp,\[Zeta]nh]+term2L[t20Lp,t21Lp,t22Lp,t2m1p,\[Zeta]nh]\[Zeta]1nh;
matrixJ2ndorder[drm1hp,\[Zeta]nh,\[Zeta]1nh,t0Lp,t1Lp,t2Lp,t3Lp,t20Lp,t21Lp,t22Lp,t2m1p];

\[Delta]M=LinearSolve[matrixJ2nd,-MG];
\[Zeta]n=Join[(*{\[Zeta]boun},*)\[Zeta]n[[1;;-2]]+\[Delta]M,{zetalast}];
err+=Total[Abs[\[Delta]M]];
err/=(nx-exc);
(*Print[{aa,err}];*)
If[err<errTol,Break[]];
},{aa,1,200}
];
\[Zeta]1n=connection[\[Zeta]n];}
]


matrixJ2ndorder[drm1hp_,\[Zeta]nhp_,\[Zeta]1nhp_,t0Lf_,t1Lf_,t2Lf_,t3Lf_,t20Lf_,t21Lf_,t22Lf_,t2m1f_]:=
Block[{\[Zeta]nh2s,\[Zeta]nh2srev,b1,b2,b3,allb1b2},
\[Zeta]nh2s=\[Zeta]nhp^2;
\[Zeta]nh2srev=1/\[Zeta]nh2s;
b1=(t1Lf+2t2Lf \[Zeta]nhp+3t3Lf \[Zeta]nh2s-t0Lf \[Zeta]nh2srev)/2.;
b2=(t21Lf+2t22Lf \[Zeta]nhp-t2m1f \[Zeta]nh2srev)\[Zeta]1nhp/2.;                        
b3=term2L[t20Lf,t21Lf,t22Lf,t2m1f,\[Zeta]nhp]drm1hp;
allb1b2=b1+b2;
matrixJ2nd=SparseArray[{
Band[{1,1}]->allb1b2-b3,
Band[{1,2}]->allb1b2[[1;;-2]]+b3[[1;;-2]]                    
},
{nx-1-(exc-1),nx-1-(exc-1)}];]



c1al[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Phi]np_,\[Zeta]nf_]:=(1+((Qnf rnf w1nf)/4+wnf/2) \[Beta]c+\[Alpha]c ((4 Qnf w1nf)/rnf+(4 Pnf w1nf \[Zeta]nf)/rnf^(3/2)-(2 Qnf w1nf \[Zeta]nf^2)/rnf^2))
c2al[Pnf_,P1nf_,Qnf_,rnf_,w1nf_,w2nf_,\[Phi]np_,\[Zeta]nf_,\[Zeta]1nf_]:=\[Beta]c (-((Qnf w1nf)/8)+(P1nf rnf^(3/2) w1nf)/(4 \[Zeta]nf)+(Pnf Qnf rnf^(3/2) w2nf)/(4 \[Zeta]nf)+(Qnf rnf w1nf \[Zeta]1nf)/(4 \[Zeta]nf))+(Pnf Qnf rnf^(3/2))/(4 \[Zeta]nf)+\[Alpha]c (-((2 P1nf w1nf \[Zeta]nf)/rnf^(3/2))-(2 Pnf Qnf w2nf \[Zeta]nf)/rnf^(3/2)-(2 Qnf w1nf \[Zeta]1nf \[Zeta]nf)/rnf^2+(Qnf w1nf \[Zeta]nf^2)/rnf^3)
(*c1al[Pfn,Qfn,\[Zeta]fn,W1fn,rgrids] \[Alpha]dr+\[Alpha]fn c2al[Pfn,Qfn,\[Zeta]fn,W1fn,rgrids]=0*)


(*c1al[Pfn,Qfn,\[Zeta]fn,W1fn,rgrids] \[Alpha]dr+\[Alpha]fn c2al[Pfn,Qfn,\[Zeta]fn,W1fn,rgrids]=0*)

alphasolver2ndorder[drm1hp_,pnhp_,p1nhp_,qnhp_,rn1d2p_,wnhp_,w1nhp_,w2nhp_,\[Phi]nhp_,\[Zeta]np_]:=
Block[{m1,m2,matrixal,matrixRal,
\[Zeta]nhp=(\[Zeta]np[[1;;-2]]+\[Zeta]np[[2;;-1]])/2.,
\[Zeta]1nhp=(\[Zeta]np[[2;;-1]]-\[Zeta]np[[1;;-2]])drm1hp},
{
m1=c1al[pnhp,qnhp,rn1d2p,wnhp,w1nhp,\[Phi]nhp,\[Zeta]nhp]drm1hp;
m2=c2al[pnhp,p1nhp,qnhp,rn1d2p,w1nhp,w2nhp,\[Phi]nhp,\[Zeta]nhp,\[Zeta]1nhp]/2.;
matrixal=SparseArray[{
{-1,-1}->1,
{-2,-1}->0,{-2,-2}->1,
Band[{1,1}]->-m1+m2,
Band[{1,2}]->m1+m2},
{nx-(exc-1),nx-(exc-1)}
];

matrixRal=Join[Table[0.,{i,1,Length[m1]-1}],{1,1.}];
\[Alpha]n=Join[LinearSolve[matrixal,matrixRal]];
\[Alpha]1n=connection[\[Alpha]n];
}]


(*connection between constraints and evolution)
d1=-1./12;d2=2./3;
geder[vm2_,vm1_,vp1_,vp2_,dxpc_]:=(d1 vp2+d2 vp1-d2 vm1-d1 vm2)dxpc
gederco={-d1,-d2,d2,d1};
in1der[v0_,vp1_,vp2_,vp3_,vp4_,dxp0_]:=(((-1.)/4.)vp4+(4/3.)vp3+(-3.)vp2+4.vp1+((-25.)/12.)v0)dxp0
in1derco={-(25./12),4.,-3.,4./3,(-1.)/4};
in2der[vm1_,v0_,vp1_,vp2_,vp3_,dxp1_]:=((1/12.)vp3+((-1)/2.)vp2+(3./2.)vp1+((-5.)/6.)v0+((-1.)/4.)vm1)dxp1
in2derco={(-1.)/4,-(5./6),3./2,-(1./2),1./12};
out1der[m4_,m3_,m2_,m1_,p0_,h_]:=((1./4)m4-(4./3)m3+3.m2-4.m1+(25./12)p0)h;
out1derco={1./4,-(4./3),3.,-4.,25./12};
out2der[vm3_,vm2_,vm1_,v0_,vp1_,dxm1_]:=((1./4.)vp1+(5./6.)v0+((-3.)/2.)vm1+(1./2.)vm2+((-1.)/12.)vm3)dxm1
out2derco={(-1.)/12,1./2,-(3./2),5./6,1./4};


grids[excp_]:={xgrids=xd[rh+small]+dx (Range[excp-1,nx-1]);
rgrids=Join[r[xgrids[[1;;-2]]],{rinfty}];
rn=rgrids;(*generating the radial grids*)dr=Join[dx rd[xgrids[[1;;-2]]],{rinfty-dx rd[xgrids[[-2]]]}];
drm1=1./dr,x1d2=(xgrids[[1;;-2]]+xgrids[[2;;-1]])/2.;
rn1d2=r[x1d2];
dr1d2=dx rd[x1d2];
drm1h=1/dr1d2}



connection[fnp_]:=
Block[
{fdr=geder[#[[1;;-5]],#[[2;;-4]],#[[4;;-2]],#[[5;;-1]],drm1[[3;;-3]]]&@fnp,
fdrin1=in1der[#[[1]],#[[2]],#[[3]],#[[4]],#[[5]],drm1[[1]]]&@fnp,
fdrin2=in2der[#[[1]],#[[2]],#[[3]],#[[4]],#[[5]],drm1[[2]]]&@fnp,
fdrout2=out2der[#[[-5]],#[[-4]],#[[-3]],#[[-2]],#[[-1]],drm1[[-2]]]&@fnp,
fdrout1=out1der[#[[-5]],#[[-4]],#[[-3]],#[[-2]],#[[-1]],drm1[[-1]]]&@fnp
},
Join[{fdrin1,fdrin2},fdr,{fdrout2,fdrout1}]]


phipouterpoint[flast_,fnow_]:=Block[{},
(*1/(dr1d2[[-1]]dt+2(dr1d2[[-1]]+dt)rn1d2[[-1]])((-dr1d2[[-1]]dt+2(dr1d2[[-1]]+dt)rn1d2[[-1]])flast[[-2]]-(dr1d2[[-1]](dt-2rn1d2[[-1]])+2dt rn1d2[[-1]])flast[[-1]]+(2dt rn1d2[[-1]]-dr1d2[[-1]](dt+2rn1d2[[-1]]))fnow[[-2]])*)0
]


qouterpoint[philast_,phinow_,flast_,fnow_]:=Block[{
(*qqouter=(philast[[-1]]+philast[[-1]]+phinow[[-2]]+phinow[[-2]])/(4rn1d2[[-1]])*)
},
(*1/(dr1d2[[-1]]dt+2(dr1d2[[-1]]+dt)rn1d2[[-1]])(4 dr1d2[[-1]]dt qqouter+(-dr1d2[[-1]]dt+2(dr1d2[[-1]]+dt)rn1d2[[-1]])flast[[-2]]-(dr1d2[[-1]](dt-2rn1d2[[-1]])+2dt rn1d2[[-1]])flast[[-1]]+(2dt rn1d2[[-1]]-dr1d2[[-1]](dt+2rn1d2[[-1]]))fnow[[-2]])*)0
]


evolutionTime[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,vpdnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Phi]nf_,\[Zeta]nf_,\[Zeta]1nf_]:=
Block[{
a1=eqd\[Phi]dt[Pnf[[1;;-2]],Qnf[[1;;-2]],rnf[[1;;-2]],\[Alpha]nf[[1;;-2]],\[Zeta]nf[[1;;-2]]],
a2=denominater[Pnf[[1;;-2]],Qnf[[1;;-2]],Q1nf[[1;;-2]],rnf[[1;;-2]],wnf[[1;;-2]],w1nf[[1;;-2]],w2nf[[1;;-2]],\[Alpha]nf[[1;;-2]],\[Alpha]1nf[[1;;-2]],\[Phi]nf[[1;;-2]],\[Zeta]nf[[1;;-2]],\[Zeta]1nf[[1;;-2]]],
a3=eqdpdtnominater[Pnf[[1;;-2]],P1nf[[1;;-2]],Qnf[[1;;-2]],Q1nf[[1;;-2]],rnf[[1;;-2]],vpnf[[1;;-2]],vpdnf[[1;;-2]],wnf[[1;;-2]],w1nf[[1;;-2]],w2nf[[1;;-2]],\[Alpha]nf[[1;;-2]],\[Alpha]1nf[[1;;-2]],\[Phi]nf[[1;;-2]],\[Zeta]nf[[1;;-2]],\[Zeta]1nf[[1;;-2]]],
a4=eqdqdt[Pnf[[1;;-2]],P1nf[[1;;-2]],Qnf[[1;;-2]],Q1nf[[1;;-2]],rnf[[1;;-2]],\[Alpha]nf[[1;;-2]],\[Alpha]1nf[[1;;-2]],\[Zeta]nf[[1;;-2]],\[Zeta]1nf[[1;;-2]]],
a5=eqd\[Zeta]dtnominater[Pnf[[1]],P1nf[[1]],Qnf[[1]],Q1nf[[1]],rnf[[1]],vpnf[[1]],vpdnf[[1]],wnf[[1]],w1nf[[1]],w2nf[[1]],\[Alpha]nf[[1]],\[Alpha]1nf[[1]],\[Phi]nf[[1]],\[Zeta]nf[[1]],\[Zeta]1nf[[1]]]
},
{a1,a3 a2,a4,a5 a2[[1]]}]


RKkq1:={
k1= dt*eqd\[Phi]dt[Pn[[1;;-2]],Qn[[1;;-2]],rn[[1;;-2]],\[Alpha]n[[1;;-2]],\[Zeta]n[[1;;-2]]];     
l1= dt*dpdt0;     
m1= dt*eqdqdt[Pn[[1;;-2]],P1n[[1;;-2]],Qn[[1;;-2]],Q1n[[1;;-2]],rn[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];         
n1= dt*d\[Zeta]dt0;
};


RKkq2:={
{\[Phi]n[[1;;-2]],Pn[[1;;-2]],Qn[[1;;-2]]}={\[Phi]fnL[[1;;-2]]+k1/2.,PfnL[[1;;-2]]+l1/2.,QfnL[[1;;-2]]+m1/2.};

{\[Phi]n,Pn,Qn}+={\[Phi]ndiss,Pndiss,Qndiss}/2.;
{Pn[[-1]],\[Phi]n[[-1]]}={phipouterpoint[PfnL,Pn],phipouterpoint[\[Phi]fnL,\[Phi]n]};
Qn[[-1]]=qouterpoint[\[Phi]fnL,\[Phi]n,QfnL,Qn];
couplingsn[\[Phi]n];
{P1n,Q1n}=connection[#]&/@{Pn,Qn};
\[Zeta]boun=\[Zeta]fnL[[1]]+n1/2.+\[Zeta]ndiss[[1]]/2.;
zealsolvers2ndorder[drm1h,Pn,Qn,rn1d2,vpn,wn,w1n,w2n,\[Phi]n];

{k2,l2,m2,n2}=dt*evolutionTime[Pn,P1n,Qn,Q1n,rn,vpn,vpdn,wn,w1n,w2n,\[Alpha]n,\[Alpha]1n,\[Phi]n,\[Zeta]n,\[Zeta]1n]
};


RKkq3:={
{\[Phi]n[[1;;-2]],Pn[[1;;-2]],Qn[[1;;-2]]}={\[Phi]fnL[[1;;-2]]+k2/2.,PfnL[[1;;-2]]+l2/2.,QfnL[[1;;-2]]+m2/2.};
{\[Phi]n,Pn,Qn}+={\[Phi]ndiss,Pndiss,Qndiss}/2.;
{Pn[[-1]],\[Phi]n[[-1]]}={phipouterpoint[PfnL,Pn],phipouterpoint[\[Phi]fnL,\[Phi]n]};
Qn[[-1]]=qouterpoint[\[Phi]fnL,\[Phi]n,QfnL,Qn];

couplingsn[\[Phi]n];
{P1n,Q1n}=connection[#]&/@{Pn,Qn};

\[Zeta]boun=\[Zeta]fnL[[1]]+n2/2.+\[Zeta]ndiss[[1]]/2.;
zealsolvers2ndorder[drm1h,Pn,Qn,rn1d2,vpn,wn,w1n,w2n,\[Phi]n];
{k3,l3,m3,n3}=dt*evolutionTime[Pn,P1n,Qn,Q1n,rn,vpn,vpdn,wn,w1n,w2n,\[Alpha]n,\[Alpha]1n,\[Phi]n,\[Zeta]n,\[Zeta]1n];
};


RKkq4:={
{\[Phi]n[[1;;-2]],Pn[[1;;-2]],Qn[[1;;-2]]}={\[Phi]fnL[[1;;-2]]+k3,PfnL[[1;;-2]]+l3,QfnL[[1;;-2]]+m3};

{\[Phi]n,Pn,Qn}+={\[Phi]ndiss,Pndiss,Qndiss};
{Pn[[-1]],\[Phi]n[[-1]]}={phipouterpoint[PfnL,Pn],phipouterpoint[\[Phi]fnL,\[Phi]n]};
Qn[[-1]]=qouterpoint[\[Phi]fnL,\[Phi]n,QfnL,Qn];
couplingsn[\[Phi]n];
{P1n,Q1n}=connection[#]&/@{Pn,Qn};
\[Zeta]boun=\[Zeta]fnL[[1]]+n3+\[Zeta]ndiss[[1]];
zealsolvers2ndorder[drm1h,Pn,Qn,rn1d2,vpn,wn,w1n,w2n,\[Phi]n];
{k4,l4,m4,n4}=dt*evolutionTime[Pn,P1n,Qn,Q1n,rn,vpn,vpdn,wn,w1n,w2n,\[Alpha]n,\[Alpha]1n,\[Phi]n,\[Zeta]n,\[Zeta]1n];
};


RKnext:=
Block[{b1,b2,b3},{
{\[Phi]n[[1;;-2]]=\[Phi]fnL[[1;;-2]]+(k1+2k2+2k3+k4)/6.,
Pn[[1;;-2]]=PfnL[[1;;-2]]+(l1+2l2+2l3+l4)/6.,
Qn[[1;;-2]]=QfnL[[1;;-2]]+(m1+2m2+2m3+m4)/6.,
                 \[Zeta]boun=\[Zeta]fnL[[1]]+(n1+2n2+2n3+n4)/6.};

{\[Phi]n,Pn,Qn, \[Zeta]boun}+={\[Phi]ndiss,Pndiss,Qndiss,\[Zeta]ndiss[[1]]}; (*\:8ba1\:7b97\:4e0b\:4e00\:4e2a\:65f6\:95f4\:5c42\:7684\[Phi],P,\:5e76\:5229\:7528BO\:8865\:507f*)
{Pn[[-1]],\[Phi]n[[-1]]}={phipouterpoint[PfnL,Pn],phipouterpoint[\[Phi]fnL,\[Phi]n]};
Qn[[-1]]=qouterpoint[\[Phi]fnL,\[Phi]n,QfnL,Qn];
couplingsn[\[Phi]n];

{P1n,Q1n}=connection[#]&/@{Pn,Qn};
zealsolvers2ndorder[drm1h,Pn,Qn,rn1d2,vpn,wn,w1n,w2n,\[Phi]n];

b1=denominater[Pn[[1;;-2]],Qn[[1;;-2]],Q1n[[1;;-2]],rn[[1;;-2]],wn[[1;;-2]],w1n[[1;;-2]],w2n[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Phi]n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];
b2=eqdpdtnominater[Pn[[1;;-2]],P1n[[1;;-2]],Qn[[1;;-2]],Q1n[[1;;-2]],rn[[1;;-2]],vpn[[1;;-2]],vpdn[[1;;-2]],wn[[1;;-2]],w1n[[1;;-2]],w2n[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Phi]n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];
b3=eqd\[Zeta]dtnominater[Pn[[1;;-2]],P1n[[1;;-2]],Qn[[1;;-2]],Q1n[[1;;-2]],rn[[1;;-2]],vpn[[1;;-2]],vpdn[[1;;-2]],wn[[1;;-2]],w1n[[1;;-2]],w2n[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Phi]n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];     
d\[Zeta]dt=b3 b1;          
dpdt=b2 b1;
(*\:7ed9\:51fa\:4e0b\:4e00\:4e2a\:65f6\:95f4\:5c42\:51fd\:6570\:79bb\:6563\:503cdpdt\:7528\:6765\:8fdb\:884c\:5206\:6790\:ff0c\:51cf\:5c11\:5728state\:548ceomrr\:5206\:6790\:8fc7\:7a0b\:4e2d\:7684\:8ba1\:7b97\:91cf\:ff0c\:6548\:679c\:660e\:663e,\:5355\:5faa\:73af\:51cf\:65f6\:95f41/4*)
}];


Main:={RKkq1;RKkq2;RKkq3;RKkq4;RKnext;}
mtotal:=(*rn[[1;;-2]]*) \[Zeta]n^2/2;


stopcondition:=If[pt<10^-14,Break[]];


state[dpdtp_,d\[Zeta]dtp_,Pnf_,P1nf_,Qnf_, Q1nf_,rnp_,vpnp_,vpdnp_,wnp_,w1np_,w2np_,\[Alpha]np_,\[Phi]np_,\[Zeta]np_]:=Block[{BndAn,Bin,newexc,r1,r2,r3,r4,r5,r6,r7,r8,(*count,*)An,Bn,Cn,Dn,ingoingc,outgoingc,i,
dpdtf=dpdtp,pnf=Pnf[[1;;-2]],p1nf=P1nf[[1;;-2]],qnf=Qnf[[1;;-2]],q1nf=Q1nf[[1;;-2]],rnf=rnp[[1;;-2]],\[Alpha]nf=\[Alpha]np[[1;;-2]],(*\[Alpha]1nf=\[Alpha]1np[[1;;-2]],*)vpnf=vpnp[[1;;-2]],wnf=wnp[[1;;-2]],w1nf=w1np[[1;;-2]],w2nf=w2np[[1;;-2]],\[Phi]nf=\[Phi]np[[1;;-2]],\[Zeta]nf=\[Zeta]np[[1;;-2]](*,\[Zeta]1nf=\[Zeta]1np[[1;;-2]]*)
},
status=0;
r1=PdtP[pnf,qnf,q1nf,rnf,vpnf,wnf,w1nf,w2nf,\[Alpha]nf,\[Phi]nf,\[Zeta]nf];                  
r2=PdtQ;
r3=PdrP[pnf,p1nf,qnf,q1nf,rnf,vpnf,wnf,w1nf,w2nf,\[Alpha]nf,\[Phi]nf,\[Zeta]nf];
r4=PdrQ[dpdtf,pnf,p1nf,qnf,q1nf,rnf,vpnf,wnf,w1nf,w2nf,\[Alpha]nf,\[Phi]nf,\[Zeta]nf];    
r5=QdtP;
r6=QdtQ; 
r7=QdrP[pnf,qnf,rnf,wnf,w1nf,\[Alpha]nf,\[Phi]nf,\[Zeta]nf]; 
r8=QdrQ[pnf,qnf,rnf,wnf,w1nf,\[Alpha]nf,\[Phi]nf,\[Zeta]nf];               (*\:5229\:7528Pfn\:8ba1\:7b97*)
An=r1 r6-r2 r5;
Bn=-(r1 r8-r2 r7)-(r3 r6-r4 r5);
Cn=r3 r8-r4 r7;
Dn=Bn^2-4.An Cn;
ingoingc=0 #&@Range[1,outbnum];
outgoingc=0 #&@Range[1,outbnum];
newexc=exc;count=1;
(*\:8ba1\:7b97\:5f53\:524d\:7a7a\:95f4\:8303\:56f4\:5728\:4e0b\:4e00\:4e2a\:65f6\:95f4\:5c42\:7684\:692d\:5706\:6027 \:5982\:679c\:91cd\:65b0\:5207\:5272\:ff0c\:5219\:91cd\:65b0\:9650\:5b9a\:4e0b\:4e00\:4e2a\:65f6\:95f4\:5c42\:7684\:8ba1\:7b97\:8303\:56f4\:4ecenewexc\:5230\:6570\:7ec4-1\:4f4d\:7f6e*)
i=1;dnlist={};
While[i<=outbnum-1,
{If[Dn[[i]]<0.0001,{count=i+1,status=-1,newexc=exc+i,dn=AppendTo[dnlist,Dn[[i]]]},            
{BndAn=-Bn[[i]]/(2.An[[i]]),  Bin=Sqrt[Dn[[i]]]/(2.An[[i]]),
ingoingc[[i]]=BndAn-Bin,    
outgoingc[[i]]=BndAn+Bin
}];
++i
};
];
exc=newexc;
outbnum=nx-(exc-1);
]


nextslice:=Block[{},
{If[status==-1,{grids[exc];
{dpdt,d\[Zeta]dt,\[Phi]n,Pn,Qn,\[Alpha]n,\[Zeta]n}=Drop[#,count-1]&/@{dpdt,d\[Zeta]dt,\[Phi]fnL,PfnL,QfnL,\[Alpha]fnL,\[Zeta]fnL};
{P1n,Q1n,\[Alpha]1n,\[Zeta]1n}=connection[#]&/@{Pn, Qn,\[Alpha]n,\[Zeta]n};
couplingsn[\[Phi]n];
KO=kodissMatrix6order;
{KO.Pn,KO.Qn,KO.\[Alpha]n,KO.\[Zeta]n};
\[Zeta]boun=\[Zeta]n[[1]];
}];       (*\:91cd\:65b0\:89c4\:5212\:683c\:70b9\:ff0c\:5e76\:5229\:7528RKnext\:91cc\:9762\:7684\:51fd\:6570\:91cd\:65b0\:751f\:6210\:6570\:7ec4Pfn*)
{\[Phi]fnL=\[Phi]n, PfnL=Pn, QfnL=Qn, \[Alpha]fnL=\[Alpha]n, \[Zeta]fnL=\[Zeta]n};

{\[Phi]ndiss,Pndiss,Qndiss,\[Zeta]ndiss}={KO.\[Phi]fnL,KO.PfnL,KO.QfnL,KO.\[Zeta]fnL}(eps/64.);
         (*\:8bb0\:5f55\:65b0\:65f6\:95f4\:5c42\:9762\:7684\:51fd\:6570\:503c*)
dpdt0=dpdt;
d\[Zeta]dt0=d\[Zeta]dt[[1]];
}(*\:5b58\:50a8\:5728\:5206\:6790\:8d85\:66f2\:9762\:6027\:8d28\:65f6\:5019\:7684\:8ba1\:7b97\:6570\:503c\:ff0c\:7528\:4f5c\:4e0b\:4e00\:4e2a\:65f6\:95f4\:5faa\:73af\:8ba1\:7b97\:7528*)

]


kodissMatrix6order:=NDSolve`FiniteDifferenceDerivative[Derivative[6],Range[Length[xgrids]],"DifferenceOrder"->1]["DifferentiationMatrix"];


QdtP=0;                
QdrP[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Alpha]nf_,\[Phi]np_,\[Zeta]nf_]:=-((\[Alpha]nf (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+6 Pnf w1nf \[Alpha]c \[Zeta]nf))/(rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+4 Pnf w1nf \[Alpha]c \[Zeta]nf))
QdtQ=1.;QdrQ[Pnf_,Qnf_,rnf_,wnf_,w1nf_,\[Alpha]nf_,\[Phi]np_,\[Zeta]nf_]:=-((\[Alpha]nf \[Zeta]nf (rnf^(3/2)+2 Qnf Sqrt[rnf] w1nf \[Alpha]c+4 Pnf w1nf \[Alpha]c \[Zeta]nf))/(rnf^2+4 Qnf rnf w1nf \[Alpha]c+4 Pnf Sqrt[rnf] w1nf \[Alpha]c \[Zeta]nf))
PdtQ=0;

(*d*)PdtP[Pnf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Phi]nf_,\[Zeta]nf_]:=-((rnf^(15/2)+12 Qnf rnf^(13/2) w1nf \[Alpha]c+48 Qnf^2 rnf^(11/2) w1nf^2 \[Alpha]c^2+14 Pnf rnf^6 w1nf \[Alpha]c \[Zeta]nf+112 Pnf Qnf rnf^5 w1nf^2 \[Alpha]c^2 \[Zeta]nf+224 Pnf Qnf^2 rnf^4 w1nf^3 \[Alpha]c^3 \[Zeta]nf+32 Qnf rnf^(7/2) (9 Pnf^2+Qnf^2+2 vpnf) w1nf^3 \[Alpha]c^3 \[Zeta]nf^2+24 Pnf rnf^3 (5 Pnf^2+Qnf^2+2 vpnf) w1nf^3 \[Alpha]c^3 \[Zeta]nf^3-48 rnf^(3/2) w1nf^2 \[Alpha]c^2 (1+4 Q1nf w1nf \[Alpha]c+4 Qnf^2 w2nf \[Alpha]c) \[Zeta]nf^4-192 Qnf Sqrt[rnf] w1nf^3 \[Alpha]c^3 (1+4 Q1nf w1nf \[Alpha]c+4 Qnf^2 w2nf \[Alpha]c) \[Zeta]nf^4-192 Pnf w1nf^3 \[Alpha]c^3 (1+4 Q1nf w1nf \[Alpha]c+4 Qnf^2 w2nf \[Alpha]c) \[Zeta]nf^5+8 rnf^(9/2) w1nf^2 \[Alpha]c^2 (8 Qnf^3 w1nf \[Alpha]c+Qnf^2 \[Zeta]nf^2+(9 Pnf^2+2 vpnf) \[Zeta]nf^2))/(rnf^3 \[Alpha]nf (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+4 Pnf w1nf \[Alpha]c \[Zeta]nf)^2 (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+6 Pnf w1nf \[Alpha]c \[Zeta]nf)))


(*d*)PdrQ[dpdt_,Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Phi]nf_,\[Zeta]nf_]:=(rnf^(19/2) \[Alpha]nf+16 Qnf rnf^(17/2) w1nf \[Alpha]c \[Alpha]nf+96 Qnf^2 rnf^(15/2) w1nf^2 \[Alpha]c^2 \[Alpha]nf+16 Pnf rnf^8 w1nf \[Alpha]c \[Alpha]nf \[Zeta]nf+192 Pnf Qnf rnf^7 w1nf^2 \[Alpha]c^2 \[Alpha]nf \[Zeta]nf+768 Pnf Qnf^2 rnf^6 w1nf^3 \[Alpha]c^3 \[Alpha]nf \[Zeta]nf+64 Qnf^2 rnf^(9/2) (22 Pnf^2-3 Qnf^2+4 vpnf) w1nf^4 \[Alpha]c^4 \[Alpha]nf \[Zeta]nf^2+64 Pnf Qnf rnf^4 (12 Pnf^2-7 Qnf^2+8 vpnf) w1nf^4 \[Alpha]c^4 \[Alpha]nf \[Zeta]nf^3+384 Qnf rnf^(5/2) w1nf^3 \[Alpha]c^3 (4 dpdt w1nf \[Alpha]c+(-1+4 Pnf^2 w2nf \[Alpha]c) \[Alpha]nf) \[Zeta]nf^4+16 rnf^(7/2) w1nf^2 \[Alpha]c^2 (12 dpdt w1nf \[Alpha]c+(-3+8 Pnf^4 w1nf^2 \[Alpha]c^2+Qnf^4 w1nf^2 \[Alpha]c^2+2 Qnf^2 vpnf w1nf^2 \[Alpha]c^2+Pnf^2 \[Alpha]c (12 w2nf+(-15 Qnf^2+16 vpnf) w1nf^2 \[Alpha]c)) \[Alpha]nf) \[Zeta]nf^4-192 P1nf rnf^3 w1nf^3 \[Alpha]c^3 \[Alpha]nf \[Zeta]nf^5+384 rnf^2 w1nf^3 \[Alpha]c^3 (4 dpdt Pnf w1nf \[Alpha]c+(-3 P1nf Qnf w1nf \[Alpha]c+4 Pnf^3 w2nf \[Alpha]c+Pnf (-1+Qnf^2 w2nf \[Alpha]c)) \[Alpha]nf) \[Zeta]nf^5+1536 Qnf rnf w1nf^4 \[Alpha]c^4 (4 dpdt Pnf w1nf \[Alpha]c+(-P1nf Qnf w1nf \[Alpha]c+4 Pnf^3 w2nf \[Alpha]c+Pnf (-1+Qnf^2 w2nf \[Alpha]c)) \[Alpha]nf) \[Zeta]nf^5+768 Pnf Sqrt[rnf] w1nf^4 \[Alpha]c^4 (4 dpdt Pnf w1nf \[Alpha]c+(-6 P1nf Qnf w1nf \[Alpha]c+4 Pnf^3 w2nf \[Alpha]c+Pnf (-1+2 Qnf^2 w2nf \[Alpha]c)) \[Alpha]nf) \[Zeta]nf^6-3072 P1nf Pnf^2 w1nf^5 \[Alpha]c^5 \[Alpha]nf \[Zeta]nf^7+16 Pnf rnf^5 w1nf^3 \[Alpha]c^3 \[Alpha]nf \[Zeta]nf (64 Qnf^3 w1nf \[Alpha]c-7 Qnf^2 \[Zeta]nf^2+4 (3 Pnf^2+2 vpnf) \[Zeta]nf^2)+32 Qnf rnf^(11/2) w1nf^3 \[Alpha]c^3 \[Alpha]nf (8 Qnf^3 w1nf \[Alpha]c-3 Qnf^2 \[Zeta]nf^2+2 (11 Pnf^2+2 vpnf) \[Zeta]nf^2)+4 rnf^(13/2) w1nf^2 \[Alpha]c^2 \[Alpha]nf (64 Qnf^3 w1nf \[Alpha]c-3 Qnf^2 \[Zeta]nf^2+2 (11 Pnf^2+2 vpnf) \[Zeta]nf^2)+768 rnf^(3/2) w1nf^4 \[Alpha]c^4 \[Zeta]nf^4 (4 dpdt Qnf^2 w1nf \[Alpha]c+Qnf^2 (-1+4 Pnf^2 w2nf \[Alpha]c) \[Alpha]nf-2 P1nf Pnf \[Alpha]nf \[Zeta]nf^2))/(rnf^(7/2) \[Alpha]nf (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+4 Pnf w1nf \[Alpha]c \[Zeta]nf)^3 (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+6 Pnf w1nf \[Alpha]c \[Zeta]nf))


(*d*)PdrP[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Phi]nf_,\[Zeta]nf_]:=-((\[Zeta]nf (-rnf^9-18 Qnf rnf^8 w1nf \[Alpha]c-120 Qnf^2 rnf^7 w1nf^2 \[Alpha]c^2-18 Pnf rnf^(15/2) w1nf \[Alpha]c \[Zeta]nf-276 Pnf Qnf rnf^(13/2) w1nf^2 \[Alpha]c^2 \[Zeta]nf-1344 Pnf Qnf^2 rnf^(11/2) w1nf^3 \[Alpha]c^3 \[Zeta]nf-3712 Pnf^2 Qnf^2 rnf^4 w1nf^4 \[Alpha]c^4 \[Zeta]nf^2+3072 Qnf rnf^(5/2) w1nf^3 (P1nf w1nf+Pnf Qnf w2nf) \[Alpha]c^4 \[Zeta]nf^3+16 rnf^(7/2) w1nf^2 \[Alpha]c^3 (24 P1nf w1nf+24 Pnf Qnf w2nf-Pnf Qnf (153 Pnf^2+5 (Qnf^2+2 vpnf)) w1nf^2 \[Alpha]c) \[Zeta]nf^3+384 Qnf rnf w1nf^4 \[Alpha]c^4 (Qnf+40 P1nf Pnf w1nf \[Alpha]c+4 Q1nf Qnf w1nf \[Alpha]c+40 Pnf^2 Qnf w2nf \[Alpha]c+4 Qnf^3 w2nf \[Alpha]c) \[Zeta]nf^4-48 rnf^3 w1nf^2 \[Alpha]c^2 (-1-4 Q1nf w1nf \[Alpha]c+10 Pnf^4 w1nf^2 \[Alpha]c^2+4 Pnf^2 vpnf w1nf^2 \[Alpha]c^2+2 Qnf^2 \[Alpha]c (-2 w2nf+Pnf^2 w1nf^2 \[Alpha]c)) \[Zeta]nf^4+96 rnf^2 w1nf^3 \[Alpha]c^3 (40 P1nf Pnf w1nf \[Alpha]c+12 Qnf^3 w2nf \[Alpha]c+Qnf (3+12 Q1nf w1nf \[Alpha]c+40 Pnf^2 w2nf \[Alpha]c)) \[Zeta]nf^4+1152 Pnf Sqrt[rnf] w1nf^4 \[Alpha]c^4 (Qnf+8 P1nf Pnf w1nf \[Alpha]c+4 Q1nf Qnf w1nf \[Alpha]c+8 Pnf^2 Qnf w2nf \[Alpha]c+4 Qnf^3 w2nf \[Alpha]c) \[Zeta]nf^5+768 Pnf^2 w1nf^4 \[Alpha]c^4 (1+4 Q1nf w1nf \[Alpha]c+4 Qnf^2 w2nf \[Alpha]c) \[Zeta]nf^6-8 rnf^6 w1nf^2 \[Alpha]c^2 (44 Qnf^3 w1nf \[Alpha]c+Qnf^2 \[Zeta]nf^2+2 (8 Pnf^2+vpnf) \[Zeta]nf^2)-32 Qnf rnf^5 w1nf^3 \[Alpha]c^3 (12 Qnf^3 w1nf \[Alpha]c+Qnf^2 \[Zeta]nf^2+(45 Pnf^2+2 vpnf) \[Zeta]nf^2)-8 Pnf rnf^(9/2) w1nf^3 \[Alpha]c^3 \[Zeta]nf (264 Qnf^3 w1nf \[Alpha]c+7 Qnf^2 \[Zeta]nf^2+(51 Pnf^2+14 vpnf) \[Zeta]nf^2)+384 rnf^(3/2) w1nf^3 \[Alpha]c^3 \[Zeta]nf^3 (16 P1nf Qnf^2 w1nf^2 \[Alpha]c^2+Pnf (16 Qnf^3 w1nf w2nf \[Alpha]c^2+4 Qnf^2 w2nf \[Alpha]c \[Zeta]nf^2+(1+4 Q1nf w1nf \[Alpha]c) \[Zeta]nf^2))))/(rnf^(7/2) (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+4 Pnf w1nf \[Alpha]c \[Zeta]nf)^3 (rnf^(3/2)+4 Qnf Sqrt[rnf] w1nf \[Alpha]c+6 Pnf w1nf \[Alpha]c \[Zeta]nf)))


(*d*)
denominater[Pnf_,Qnf_,Q1nf_,rnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Phi]nf_,\[Zeta]nf_,\[Zeta]1nf_]:=1./(-16 rnf^8 \[Alpha]nf-16 rnf^8 wnf \[Alpha]nf \[Beta]c-4 rnf^8 (3 w1nf^2+wnf^2) \[Alpha]nf \[Beta]c^2-6 rnf^8 w1nf^2 wnf \[Alpha]nf \[Beta]c^3+512 Sqrt[rnf] w1nf^2 \[Alpha]c^3 \[Zeta]nf^3 (2 Qnf^2 rnf^(3/2) w2nf \[Alpha]nf \[Zeta]nf+4 Qnf Sqrt[rnf] w1nf (\[Alpha]nf \[Zeta]nf-2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+w1nf \[Zeta]nf (2 Q1nf rnf^(3/2) \[Alpha]nf+3 Pnf \[Alpha]nf \[Zeta]nf-6 Pnf rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))+8 rnf^6 w1nf \[Alpha]c (-16 Qnf rnf \[Alpha]nf-16 Pnf Sqrt[rnf] \[Alpha]nf \[Zeta]nf+8 \[Beta]c (-Qnf rnf wnf \[Alpha]nf-Pnf Sqrt[rnf] wnf \[Alpha]nf \[Zeta]nf+2 w1nf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+w1nf \[Beta]c^2 (-8 Qnf rnf w1nf \[Alpha]nf+2 Q1nf rnf^2 w1nf \[Alpha]nf+2 Qnf^2 rnf^2 w2nf \[Alpha]nf-9 Pnf Sqrt[rnf] w1nf \[Alpha]nf \[Zeta]nf+2 Pnf rnf^(3/2) w1nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+8 wnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))-128 rnf^2 w1nf^2 \[Alpha]c^2 (2 Qnf^2 rnf^3 \[Alpha]nf (rnf+w2nf \[Beta]c \[Zeta]nf^2)+Qnf (4 Pnf rnf^(7/2) \[Alpha]nf \[Zeta]nf-2 rnf^2 w1nf \[Beta]c \[Zeta]nf (\[Alpha]nf \[Zeta]nf+2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))+\[Zeta]nf^2 (2 Pnf^2 rnf^3 \[Alpha]nf+2 Q1nf rnf^3 w1nf \[Alpha]nf \[Beta]c+(2+wnf \[Beta]c) \[Zeta]nf (4 rnf \[Alpha]nf \[Zeta]1nf+4 rnf \[Alpha]1nf \[Zeta]nf-3 \[Alpha]nf \[Zeta]nf)-Pnf rnf^(3/2) w1nf \[Beta]c (3 \[Alpha]nf \[Zeta]nf+2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))))


(*d*)
eqd\[Zeta]dtnominater[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,vpdnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Phi]nf_,\[Zeta]nf_,\[Zeta]1nf_]:=-2 rnf^(17/2) \[Alpha]nf (Qnf w1nf \[Alpha]nf (4 Qnf^2 \[Alpha]c-8 vpnf \[Alpha]c+8 Q1nf w1nf \[Alpha]c \[Beta]c-8 vpdnf w1nf \[Alpha]c \[Beta]c-w1nf^2 \[Beta]c^3+4 Pnf^2 (\[Alpha]c+2 w2nf \[Alpha]c \[Beta]c))-\[Alpha]1nf (8+2 wnf^2 \[Beta]c^2-8 Q1nf w1nf^3 \[Alpha]c \[Beta]c^2+2 w1nf^2 (3-4 Qnf^2 w2nf \[Alpha]c) \[Beta]c^2+wnf \[Beta]c (8+3 w1nf^2 \[Beta]c^2)))-rnf^(19/2) \[Alpha]nf^2 (Pnf^2 (1+2 w2nf \[Beta]c) (2+wnf \[Beta]c)+Qnf^2 (2+wnf \[Beta]c+2 w1nf^2 \[Beta]c^2 (1+w2nf \[Beta]c))-2 (vpnf (2+wnf \[Beta]c)+w1nf \[Beta]c (vpdnf (2+wnf \[Beta]c)-Q1nf (2+wnf \[Beta]c+w1nf^2 \[Beta]c^2))))-(1024 Qnf w1nf^3 \[Alpha]c^3 \[Alpha]nf^2 \[Zeta]nf^6)/Sqrt[rnf]-(768 Pnf w1nf^3 \[Alpha]c^3 \[Alpha]nf^2 \[Zeta]nf^7)/rnf-2 Pnf rnf^9 w1nf \[Alpha]nf \[Beta]c (2+wnf \[Beta]c+w1nf^2 \[Beta]c^2) (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+1536 Pnf w1nf^3 \[Alpha]c^3 \[Alpha]nf \[Zeta]nf^6 (2 \[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+128 Pnf rnf^3 w1nf^3 \[Alpha]c^2 \[Alpha]nf \[Beta]c \[Zeta]nf^4 (5 \[Alpha]nf \[Zeta]1nf+2 \[Alpha]1nf \[Zeta]nf)-1536 Pnf rnf w1nf^3 \[Alpha]c^3 \[Alpha]nf \[Zeta]nf^5 (\[Alpha]1nf+2 \[Alpha]nf \[Zeta]1nf^2+2 \[Alpha]1nf \[Zeta]1nf \[Zeta]nf)-64 Sqrt[rnf] w1nf^2 \[Alpha]c^2 \[Alpha]nf \[Zeta]nf^5 (8 Qnf^2 w2nf \[Alpha]c \[Alpha]nf \[Zeta]nf+\[Alpha]nf (6+8 Q1nf w1nf \[Alpha]c+3 wnf \[Beta]c) \[Zeta]nf-16 Qnf w1nf \[Alpha]c (4 \[Alpha]nf \[Zeta]1nf+3 \[Alpha]1nf \[Zeta]nf))+128 rnf^2 w1nf^2 \[Alpha]c^2 \[Zeta]nf^4 (-16 P1nf w1nf \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]nf-16 Pnf Qnf w2nf \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]nf+Pnf w1nf (24 \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]1nf+8 \[Alpha]1nf^2 \[Alpha]c \[Zeta]nf-3 \[Alpha]nf^2 \[Beta]c \[Zeta]nf))+8 Pnf rnf^6 w1nf \[Alpha]c \[Alpha]nf \[Zeta]nf (64 Qnf w1nf \[Alpha]1nf \[Alpha]c+\[Zeta]nf (-2 \[Alpha]nf (6+3 wnf \[Beta]c+7 w1nf^2 \[Beta]c^2) \[Zeta]1nf+\[Alpha]1nf (4+2 wnf \[Beta]c-5 w1nf^2 \[Beta]c^2) \[Zeta]nf))+8 rnf^(7/2) w1nf^2 \[Alpha]c \[Zeta]nf^3 (64 \[Alpha]1nf \[Alpha]c \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]1nf+32 \[Alpha]1nf^2 \[Alpha]c (2+wnf \[Beta]c) \[Zeta]nf+\[Alpha]nf^2 (64 Qnf w1nf \[Alpha]c \[Beta]c \[Zeta]1nf-4 Qnf^2 \[Alpha]c \[Zeta]nf+(52 Pnf^2 \[Alpha]c-24 vpnf \[Alpha]c+3 \[Beta]c (2+wnf \[Beta]c)) \[Zeta]nf))-16 rnf^(11/2) w1nf \[Alpha]c \[Zeta]nf (16 Qnf^2 w1nf \[Alpha]c \[Alpha]nf (\[Alpha]nf \[Zeta]1nf-w2nf \[Alpha]1nf \[Beta]c \[Zeta]nf)-4 w1nf \[Alpha]nf \[Zeta]nf (4 Pnf^2 \[Alpha]1nf \[Alpha]c+4 Q1nf w1nf \[Alpha]1nf \[Alpha]c \[Beta]c+\[Beta]c (2+wnf \[Beta]c) \[Zeta]1nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+Qnf (8 (-Q1nf+vpdnf) w1nf \[Alpha]c \[Alpha]nf^2 \[Zeta]nf-\[Alpha]nf^2 (6+8 Pnf^2 w2nf \[Alpha]c+3 wnf \[Beta]c) \[Zeta]nf+w1nf^2 \[Beta]c (32 \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]1nf+16 \[Alpha]1nf^2 \[Alpha]c \[Zeta]nf-3 \[Alpha]nf^2 \[Beta]c \[Zeta]nf)))-rnf^8 w1nf (32 P1nf w1nf^2 \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Beta]c^2 \[Zeta]nf+8 Pnf^3 \[Alpha]c \[Alpha]nf^2 (1+2 w2nf \[Beta]c) \[Zeta]nf+Pnf (8 Qnf^2 \[Alpha]c \[Alpha]nf^2 \[Zeta]nf+16 (Q1nf-vpdnf) w1nf \[Alpha]c \[Alpha]nf^2 \[Beta]c \[Zeta]nf-\[Alpha]nf^2 (16 vpnf \[Alpha]c+\[Beta]c (2+wnf \[Beta]c)) \[Zeta]nf+w1nf^2 \[Beta]c^2 (16 \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]1nf+16 \[Alpha]1nf^2 \[Alpha]c \[Zeta]nf-3 \[Alpha]nf^2 \[Beta]c \[Zeta]nf)+16 Qnf w1nf \[Alpha]c \[Alpha]nf \[Beta]c (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf (1+2 w2nf \[Beta]c) \[Zeta]nf)))+4 rnf^5 w1nf \[Alpha]c \[Alpha]nf \[Zeta]nf^2 (32 Pnf^3 w2nf \[Alpha]c \[Alpha]nf \[Zeta]nf+128 P1nf w1nf^2 \[Alpha]1nf \[Alpha]c \[Beta]c \[Zeta]nf+Pnf (32 (Q1nf-vpdnf) w1nf \[Alpha]c \[Alpha]nf \[Zeta]nf+10 \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf+w1nf^2 \[Beta]c (-64 \[Alpha]1nf \[Alpha]c \[Zeta]1nf+9 \[Alpha]nf \[Beta]c \[Zeta]nf)-32 Qnf w1nf \[Alpha]c (3 \[Alpha]nf \[Zeta]1nf-\[Alpha]1nf (1+4 w2nf \[Beta]c) \[Zeta]nf)))+4 rnf^(13/2) \[Alpha]c (-4 Qnf w1nf \[Alpha]nf \[Zeta]nf (4 \[Alpha]nf (2+wnf \[Beta]c+2 w1nf^2 \[Beta]c^2) \[Zeta]1nf+3 w1nf^2 \[Alpha]1nf \[Beta]c^2 \[Zeta]nf)+Qnf^2 w1nf^2 \[Alpha]nf (64 \[Alpha]1nf \[Alpha]c+\[Alpha]nf \[Beta]c (5+6 w2nf \[Beta]c) \[Zeta]nf^2)+\[Zeta]nf (6 Q1nf w1nf^3 \[Alpha]nf^2 \[Beta]c^2 \[Zeta]nf+4 (Q1nf-vpdnf) w1nf \[Alpha]nf^2 (2+wnf \[Beta]c) \[Zeta]nf+4 Pnf^2 w2nf \[Alpha]nf^2 (2+wnf \[Beta]c) \[Zeta]nf-w1nf^2 \[Beta]c (16 \[Alpha]1nf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]1nf+(Pnf^2-6 vpnf) \[Alpha]nf^2 \[Zeta]nf+8 \[Alpha]1nf^2 (2+wnf \[Beta]c) \[Zeta]nf)))+64 Pnf rnf^4 w1nf^2 \[Alpha]c^2 \[Alpha]nf \[Zeta]nf^3 (11 Qnf \[Alpha]nf+2 w1nf \[Beta]c (2 \[Alpha]nf \[Zeta]1nf^2+\[Alpha]1nf (-3+2 \[Zeta]1nf \[Zeta]nf)))+8 Pnf rnf^7 w1nf \[Alpha]c \[Alpha]nf \[Zeta]nf (w1nf \[Alpha]nf \[Beta]c (Qnf+2 w1nf \[Beta]c \[Zeta]1nf^2)+\[Alpha]1nf (16+8 wnf \[Beta]c+w1nf^2 \[Beta]c^2 (9+2 \[Zeta]1nf \[Zeta]nf)))-128 rnf^(5/2) w1nf^2 \[Alpha]c^2 \[Zeta]nf^3 (8 Qnf^2 w2nf \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]nf+Qnf w1nf (-32 \[Alpha]1nf \[Alpha]c \[Alpha]nf \[Zeta]1nf-16 \[Alpha]1nf^2 \[Alpha]c \[Zeta]nf+3 \[Alpha]nf^2 \[Beta]c \[Zeta]nf)+\[Alpha]nf \[Zeta]nf (8 Q1nf w1nf \[Alpha]1nf \[Alpha]c+4 \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]1nf^2+\[Alpha]1nf (2+wnf \[Beta]c) (3+4 \[Zeta]1nf \[Zeta]nf)))+128 rnf^(3/2) w1nf^2 \[Alpha]c^2 \[Zeta]nf^4 (8 Qnf^2 w2nf \[Alpha]c \[Alpha]nf^2 \[Zeta]1nf \[Zeta]nf+\[Alpha]nf \[Zeta]nf (\[Alpha]nf (10+8 Q1nf w1nf \[Alpha]c+5 wnf \[Beta]c) \[Zeta]1nf+2 \[Alpha]1nf (2+wnf \[Beta]c) \[Zeta]nf)-16 Qnf w1nf \[Alpha]c (2 \[Alpha]nf^2 \[Zeta]1nf^2+\[Alpha]1nf^2 \[Zeta]nf^2+\[Alpha]1nf (\[Alpha]nf+3 \[Alpha]nf \[Zeta]1nf \[Zeta]nf)))-16 rnf^(9/2) w1nf^2 \[Alpha]c \[Zeta]nf^2 (\[Alpha]nf \[Zeta]nf (\[Alpha]nf \[Beta]c (2+16 Q1nf w1nf \[Alpha]c+wnf \[Beta]c) \[Zeta]1nf+\[Alpha]1nf \[Beta]c (2+wnf \[Beta]c) \[Zeta]nf+4 Pnf^2 \[Alpha]c (3 \[Alpha]nf \[Zeta]1nf-\[Alpha]1nf \[Zeta]nf)-8 vpnf \[Alpha]c (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))-16 Qnf w1nf \[Alpha]c \[Beta]c (2 \[Alpha]nf^2 \[Zeta]1nf^2+2 \[Alpha]1nf^2 \[Zeta]nf^2+\[Alpha]1nf \[Alpha]nf (-1+4 \[Zeta]1nf \[Zeta]nf))+4 Qnf^2 \[Alpha]c \[Alpha]nf (\[Alpha]1nf \[Zeta]nf^2+\[Alpha]nf (-6+\[Zeta]1nf (\[Zeta]nf+4 w2nf \[Beta]c \[Zeta]nf))))+2 rnf^(15/2) (4 Qnf^2 w1nf^2 \[Alpha]c \[Alpha]nf \[Beta]c \[Zeta]nf (\[Alpha]nf (\[Zeta]1nf+2 w2nf \[Beta]c \[Zeta]1nf)+\[Alpha]1nf \[Zeta]nf)-\[Alpha]nf \[Zeta]nf (2 \[Alpha]nf (4+2 Pnf^2 w1nf^2 \[Alpha]c \[Beta]c+4 vpnf w1nf^2 \[Alpha]c \[Beta]c+4 w1nf^2 \[Beta]c^2+wnf^2 \[Beta]c^2-4 Q1nf w1nf^3 \[Alpha]c \[Beta]c^2+2 wnf \[Beta]c (2+w1nf^2 \[Beta]c^2)) \[Zeta]1nf+w1nf^2 \[Alpha]1nf \[Beta]c (4 Pnf^2 \[Alpha]c+8 vpnf \[Alpha]c+\[Beta]c (2+wnf \[Beta]c)) \[Zeta]nf)-16 Qnf w1nf \[Alpha]1nf \[Alpha]c (w1nf^2 \[Alpha]1nf \[Beta]c^2 \[Zeta]nf^2+\[Alpha]nf (-4-2 wnf \[Beta]c+w1nf^2 \[Beta]c^2 (-2+\[Zeta]1nf \[Zeta]nf))))


(*d*)eqdpdtnominater[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,vpnf_,vpdnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Phi]nf_,\[Zeta]nf_,\[Zeta]1nf_]:=-16 Q1nf rnf^8 \[Alpha]nf^2+16 rnf^8 vpdnf \[Alpha]nf^2-16 Qnf rnf^7 \[Alpha]nf (rnf \[Alpha]1nf+2 \[Alpha]nf)-16 Pnf rnf^(15/2) \[Alpha]nf^2 \[Zeta]1nf-8 rnf^(13/2) \[Alpha]nf (2 Pnf rnf \[Alpha]1nf+3 Pnf \[Alpha]nf+2 P1nf rnf \[Alpha]nf) \[Zeta]nf-2 rnf^6 w1nf wnf \[Alpha]nf \[Beta]c^3 (2 Q1nf rnf^2 w1nf \[Alpha]nf-3 Pnf^2 rnf^2 w2nf \[Alpha]nf+2 Qnf^2 rnf^2 w2nf \[Alpha]nf+Qnf rnf w1nf (3 rnf \[Alpha]1nf+4 \[Alpha]nf)+2 Pnf rnf^(3/2) w1nf \[Alpha]nf \[Zeta]1nf+2 Pnf rnf^(3/2) w1nf \[Alpha]1nf \[Zeta]nf+3 Pnf Sqrt[rnf] w1nf \[Alpha]nf \[Zeta]nf+3 P1nf rnf^(3/2) w1nf \[Alpha]nf \[Zeta]nf+2 wnf \[Alpha]nf \[Zeta]1nf \[Zeta]nf+2 wnf \[Alpha]1nf \[Zeta]nf^2)-rnf^6 \[Alpha]nf \[Beta]c^2 (-12 Pnf^2 rnf^2 w1nf w2nf \[Alpha]nf-3 Pnf^2 rnf^2 w1nf wnf \[Alpha]nf+6 rnf^2 vpnf w1nf wnf \[Alpha]nf-4 rnf^2 vpdnf wnf^2 \[Alpha]nf+Qnf^2 rnf^2 w1nf (8 w2nf+wnf) \[Alpha]nf+4 Q1nf rnf^2 (2 w1nf^2+wnf^2) \[Alpha]nf+4 Qnf rnf (rnf (3 w1nf^2+wnf^2) \[Alpha]1nf+2 (2 w1nf^2+wnf^2) \[Alpha]nf)+8 Pnf rnf^(3/2) w1nf^2 \[Alpha]nf \[Zeta]1nf+4 Pnf rnf^(3/2) wnf^2 \[Alpha]nf \[Zeta]1nf+8 Pnf rnf^(3/2) w1nf^2 \[Alpha]1nf \[Zeta]nf+4 Pnf rnf^(3/2) wnf^2 \[Alpha]1nf \[Zeta]nf+12 Pnf Sqrt[rnf] w1nf^2 \[Alpha]nf \[Zeta]nf+12 P1nf rnf^(3/2) w1nf^2 \[Alpha]nf \[Zeta]nf+6 Pnf Sqrt[rnf] wnf^2 \[Alpha]nf \[Zeta]nf+4 P1nf rnf^(3/2) wnf^2 \[Alpha]nf \[Zeta]nf+16 w1nf wnf \[Alpha]nf \[Zeta]1nf \[Zeta]nf+16 w1nf wnf \[Alpha]1nf \[Zeta]nf^2)-2 rnf^6 \[Alpha]nf \[Beta]c (-3 Pnf^2 rnf^2 w1nf \[Alpha]nf+Qnf^2 rnf^2 w1nf \[Alpha]nf+6 rnf^2 vpnf w1nf \[Alpha]nf+8 Q1nf rnf^2 wnf \[Alpha]nf-8 rnf^2 vpdnf wnf \[Alpha]nf+8 Qnf rnf wnf (rnf \[Alpha]1nf+2 \[Alpha]nf)+8 P1nf rnf^(3/2) wnf \[Alpha]nf \[Zeta]nf+8 w1nf \[Alpha]nf \[Zeta]1nf \[Zeta]nf+8 w1nf \[Alpha]1nf \[Zeta]nf^2+4 Pnf Sqrt[rnf] wnf (2 rnf \[Alpha]nf \[Zeta]1nf+2 rnf \[Alpha]1nf \[Zeta]nf+3 \[Alpha]nf \[Zeta]nf))+4 rnf^2 w1nf \[Alpha]c (-2 Qnf^4 rnf^6 w2nf \[Alpha]nf^2 \[Beta]c+4 Qnf^3 rnf^6 w1nf w2nf \[Alpha]1nf \[Alpha]nf \[Beta]c^2-Pnf^3 rnf^(9/2) w1nf \[Alpha]nf \[Beta]c (1+2 w2nf \[Beta]c) (-9 \[Alpha]nf \[Zeta]nf+2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+2 Pnf rnf^(3/2) \[Alpha]nf (rnf^3 \[Alpha]nf (-9 vpnf w1nf \[Beta]c-8 Q1nf (2+wnf \[Beta]c)+8 vpdnf (2+wnf \[Beta]c)) \[Zeta]nf-P1nf rnf^(5/2) \[Alpha]nf (16+8 wnf \[Beta]c+9 w1nf^2 \[Beta]c^2) \[Zeta]nf^2-3 w1nf \[Alpha]nf \[Beta]c (2+wnf \[Beta]c) \[Zeta]nf^3+2 rnf^4 vpnf w1nf \[Beta]c (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+2 P1nf rnf^(7/2) w1nf^2 \[Beta]c^2 \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)-2 rnf w1nf \[Beta]c (2+wnf \[Beta]c) \[Zeta]nf^2 (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+2 Qnf rnf^2 (4 rnf^3 \[Alpha]nf^2 (w1nf \[Beta]c (Pnf^2-2 vpnf+2 Pnf^2 w2nf \[Beta]c)+2 vpdnf (2+wnf \[Beta]c))+2 Q1nf rnf^3 \[Alpha]nf (rnf w1nf^2 \[Alpha]1nf \[Beta]c^2-4 \[Alpha]nf (2+wnf \[Beta]c))-4 Pnf rnf^(3/2) \[Alpha]nf^2 (14+7 wnf \[Beta]c+6 w1nf^2 \[Beta]c^2) \[Zeta]nf-4 rnf w1nf \[Alpha]nf^2 \[Beta]c (2+wnf \[Beta]c) \[Zeta]1nf \[Zeta]nf-2 w1nf \[Alpha]nf^2 \[Beta]c (2+wnf \[Beta]c) \[Zeta]nf^2+2 Pnf rnf^(7/2) w1nf^2 \[Alpha]1nf \[Beta]c^2 (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)-rnf^(5/2) \[Alpha]nf (8 Pnf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]1nf+8 P1nf \[Alpha]nf (2+wnf \[Beta]c+w1nf^2 \[Beta]c^2) \[Zeta]nf+Pnf \[Alpha]1nf (32+16 wnf \[Beta]c+9 w1nf^2 \[Beta]c^2+8 w2nf \[Beta]c (2+wnf \[Beta]c)) \[Zeta]nf))-2 Pnf^2 rnf^3 \[Alpha]nf (Q1nf rnf^3 w1nf \[Alpha]nf \[Beta]c (1+2 w2nf \[Beta]c)+2 \[Zeta]nf (6 \[Alpha]nf (2+wnf \[Beta]c+w1nf^2 \[Beta]c^2) \[Zeta]nf+rnf (5+4 w2nf \[Beta]c) (2+wnf \[Beta]c) (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))-Qnf^2 rnf^3 \[Alpha]nf (16 rnf^2 \[Alpha]1nf (2+wnf \[Beta]c+w1nf^2 \[Beta]c^2)+2 rnf^3 \[Alpha]nf \[Beta]c (Q1nf w1nf-2 vpnf w2nf+Pnf^2 w2nf (1+2 w2nf \[Beta]c))-Pnf rnf^(3/2) w1nf \[Alpha]nf \[Beta]c \[Zeta]nf-4 \[Alpha]nf (2+w2nf \[Beta]c) (2+wnf \[Beta]c) \[Zeta]nf^2+2 rnf^(5/2) w1nf \[Beta]c (Pnf \[Alpha]nf \[Zeta]1nf+Pnf \[Alpha]1nf \[Zeta]nf-2 P1nf w2nf \[Alpha]nf \[Beta]c \[Zeta]nf)+4 rnf (\[Alpha]1nf (2+wnf \[Beta]c) \[Zeta]nf^2+wnf \[Alpha]nf \[Beta]c (8+\[Zeta]1nf \[Zeta]nf)+2 \[Alpha]nf (8+3 w1nf^2 \[Beta]c^2+\[Zeta]1nf \[Zeta]nf)))+4 (Q1nf rnf^3 w1nf \[Alpha]nf^2 \[Beta]c (rnf^3 vpnf+P1nf rnf^(5/2) w1nf \[Beta]c \[Zeta]nf+(2+wnf \[Beta]c) \[Zeta]nf^2)+(2+wnf \[Beta]c) \[Zeta]nf (4 rnf^3 \[Alpha]1nf^2 (2+wnf \[Beta]c) \[Zeta]nf+3 \[Alpha]nf^2 (2+wnf \[Beta]c) \[Zeta]nf^3+2 rnf^4 vpnf \[Alpha]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)-4 rnf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf^2 (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+4 P1nf rnf^(7/2) w1nf \[Alpha]nf \[Beta]c (-rnf \[Alpha]1nf+\[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))))+512 w1nf \[Alpha]c^3 \[Zeta]nf^2 (2 Qnf^3 rnf^2 w1nf w2nf \[Alpha]1nf \[Alpha]nf \[Zeta]nf^2+2 Qnf^2 (4 rnf^3 w1nf^2 \[Alpha]1nf^2+4 Pnf rnf^(5/2) w1nf w2nf \[Alpha]1nf \[Alpha]nf \[Zeta]nf-Pnf^2 rnf^2 w2nf^2 \[Alpha]nf^2 \[Zeta]nf^2+P1nf rnf^(3/2) w1nf w2nf \[Alpha]nf^2 \[Zeta]nf^3)+w1nf \[Zeta]nf^2 (2 Pnf^2 rnf^2 (4 w1nf \[Alpha]1nf^2-Q1nf w2nf \[Alpha]nf^2)+2 P1nf Q1nf rnf^(3/2) w1nf \[Alpha]nf^2 \[Zeta]nf+3 Pnf^3 Sqrt[rnf] w2nf \[Alpha]nf (-\[Alpha]nf \[Zeta]nf+2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+P1nf Pnf w1nf \[Alpha]nf (8 rnf^2 \[Alpha]1nf+3 \[Alpha]nf \[Zeta]nf^2-6 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))+Qnf Sqrt[rnf] w1nf \[Zeta]nf (4 Pnf^2 Sqrt[rnf] w2nf \[Alpha]nf (2 rnf \[Alpha]nf \[Zeta]1nf+4 rnf \[Alpha]1nf \[Zeta]nf-\[Alpha]nf \[Zeta]nf)+Pnf w1nf \[Alpha]1nf (16 rnf^2 \[Alpha]1nf-\[Alpha]nf \[Zeta]nf^2+2 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+2 w1nf \[Alpha]nf (Q1nf rnf^(3/2) \[Alpha]1nf \[Zeta]nf+2 P1nf (2 rnf^2 \[Alpha]1nf+\[Alpha]nf \[Zeta]nf^2-2 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))))-32 Sqrt[rnf] w1nf \[Alpha]c^2 (-2 Qnf^4 rnf^(9/2) w2nf \[Alpha]nf^2 \[Zeta]nf^2+2 Qnf^3 rnf^(7/2) w1nf \[Alpha]nf (4 rnf^2 \[Alpha]1nf-3 \[Alpha]nf \[Zeta]nf^2+2 rnf (\[Alpha]1nf (1+2 w2nf \[Beta]c) \[Zeta]nf^2+\[Alpha]nf (4+\[Zeta]1nf \[Zeta]nf)))+Qnf^2 rnf^(3/2) \[Alpha]nf (-8 rnf^4 vpdnf w1nf \[Alpha]nf-16 rnf^2 w1nf^2 \[Alpha]1nf \[Beta]c \[Zeta]nf^2-2 rnf^3 w2nf \[Alpha]nf (-2 vpnf+Pnf^2 (1+4 w2nf \[Beta]c)) \[Zeta]nf^2-5 Pnf rnf^(3/2) w1nf \[Alpha]nf \[Zeta]nf^3-4 w2nf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf^4+8 rnf^(7/2) w1nf (Pnf \[Alpha]nf \[Zeta]1nf+P1nf \[Alpha]nf \[Zeta]nf+Pnf \[Alpha]1nf (3+2 w2nf \[Beta]c) \[Zeta]nf)+2 Q1nf rnf^3 w1nf \[Alpha]nf (4 rnf-\[Zeta]nf^2)+2 rnf^(5/2) w1nf \[Zeta]nf (Pnf \[Alpha]1nf \[Zeta]nf^2+4 P1nf w2nf \[Alpha]nf \[Beta]c \[Zeta]nf^2+Pnf \[Alpha]nf (22+\[Zeta]1nf \[Zeta]nf)))+2 Qnf Sqrt[rnf] \[Zeta]nf (2 Pnf rnf^(5/2) (4 Q1nf rnf^2 w1nf \[Alpha]nf^2-4 rnf^2 vpdnf w1nf \[Alpha]nf^2+4 P1nf rnf^(3/2) w1nf \[Alpha]nf^2 \[Zeta]nf-\[Alpha]1nf \[Alpha]nf (8 w2nf+5 w1nf^2 \[Beta]c+4 w2nf wnf \[Beta]c) \[Zeta]nf^2+2 rnf w1nf^2 \[Alpha]1nf \[Beta]c \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+Pnf^2 rnf^3 w1nf \[Alpha]nf (\[Alpha]nf (21+4 w2nf \[Beta]c) \[Zeta]nf+2 rnf (\[Alpha]nf (5+4 w2nf \[Beta]c) \[Zeta]1nf+\[Alpha]1nf (7+8 w2nf \[Beta]c) \[Zeta]nf))+2 w1nf (-rnf^3 (vpnf \[Alpha]nf^2+8 \[Alpha]1nf^2 (2+wnf \[Beta]c)) \[Zeta]nf-2 \[Alpha]nf^2 (2+wnf \[Beta]c) \[Zeta]nf^3+rnf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf^2 (4 \[Alpha]nf \[Zeta]1nf+3 \[Alpha]1nf \[Zeta]nf)-2 rnf^4 \[Alpha]nf (vpnf \[Alpha]nf \[Zeta]1nf+vpnf \[Alpha]1nf \[Zeta]nf-Q1nf w1nf \[Alpha]1nf \[Beta]c \[Zeta]nf)+2 P1nf rnf^(5/2) w1nf \[Alpha]nf \[Beta]c (2 rnf^2 \[Alpha]1nf-\[Alpha]nf \[Zeta]nf^2-2 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))))+\[Zeta]nf^2 (Pnf^3 rnf^3 w1nf \[Alpha]nf (5+4 w2nf \[Beta]c) (3 \[Alpha]nf \[Zeta]nf+2 rnf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))-2 Pnf^2 rnf^(3/2) \[Alpha]nf (4 rnf^3 vpdnf w1nf \[Alpha]nf+Q1nf rnf^3 w1nf \[Alpha]nf (-3+4 w2nf \[Beta]c)-4 P1nf rnf^(5/2) w1nf \[Alpha]nf \[Zeta]nf-6 w2nf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf^2+8 rnf w2nf (2+wnf \[Beta]c) \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf))+2 Pnf w1nf (-rnf^3 (3 vpnf \[Alpha]nf^2+16 \[Alpha]1nf^2 (2+wnf \[Beta]c)) \[Zeta]nf-3 \[Alpha]nf^2 (2+wnf \[Beta]c) \[Zeta]nf^3-2 rnf^4 vpnf \[Alpha]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+6 rnf \[Alpha]nf (2+wnf \[Beta]c) \[Zeta]nf^2 (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)+2 P1nf rnf^(5/2) w1nf \[Alpha]nf \[Beta]c (4 rnf^2 \[Alpha]1nf-3 \[Alpha]nf \[Zeta]nf^2-2 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))+4 rnf w1nf \[Alpha]nf (Q1nf Sqrt[rnf] \[Alpha]nf (rnf^3 vpnf+2 P1nf rnf^(5/2) w1nf \[Beta]c \[Zeta]nf-(2+wnf \[Beta]c) \[Zeta]nf^2)+P1nf (2+wnf \[Beta]c) \[Zeta]nf (-4 rnf^2 \[Alpha]1nf-3 \[Alpha]nf \[Zeta]nf^2+4 rnf \[Zeta]nf (\[Alpha]nf \[Zeta]1nf+\[Alpha]1nf \[Zeta]nf)))))


(*d*)eqd\[Phi]dt[ Pnp_, Qnp_,rnp_,\[Alpha]fn_,\[Zeta]np_]:=\[Alpha]fn (Pnp rnp^(1/2)+ \[Zeta]np Qnp)/rnp^(1/2)

(*d*)eqdqdt[Pnf_,P1nf_,Qnf_,Q1nf_,rnf_,\[Alpha]nf_,\[Alpha]1nf_,\[Zeta]nf_,\[Zeta]1nf_]:=\[Alpha]nf (P1nf+(Qnf \[Zeta]1nf)/Sqrt[rnf]-(Qnf \[Zeta]nf)/(2 rnf^(3/2))+(Q1nf \[Zeta]nf)/Sqrt[rnf])+\[Alpha]1nf (Pnf+(Qnf \[Zeta]nf)/Sqrt[rnf])


constraint\[Zeta][Pnf_,P1nf_,Qnf_,rnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Zeta]nf_,\[Zeta]1nf_]:=\[Beta]c (-((Qnf w1nf)/8)+(P1nf rnf^(3/2) w1nf)/(4 \[Zeta]nf)+(Pnf Qnf rnf^(3/2) w2nf)/(4 \[Zeta]nf)+(Qnf rnf w1nf \[Zeta]1nf)/(4 \[Zeta]nf))+(Pnf Qnf rnf^(3/2))/(4 \[Zeta]nf)+\[Alpha]c (-((2 P1nf w1nf \[Zeta]nf)/rnf^(3/2))-(2 Pnf Qnf w2nf \[Zeta]nf)/rnf^(3/2)-(2 Qnf w1nf \[Zeta]1nf \[Zeta]nf)/rnf^2+(Qnf w1nf \[Zeta]nf^2)/rnf^3)+(\[Alpha]1nf (1+((Qnf rnf w1nf)/4+wnf/2) \[Beta]c+\[Alpha]c ((4 Qnf w1nf)/rnf+(4 Pnf w1nf \[Zeta]nf)/rnf^(3/2)-(2 Qnf w1nf \[Zeta]nf^2)/rnf^2)))/\[Alpha]nf


EOMrr[dpdtf_,d\[Zeta]dtf_,Pnf_,P1nf_,Qnf_,rnf_,vpnf_,wnf_,w1nf_,w2nf_,\[Alpha]nf_,\[Alpha]1nf_,\[Zeta]nf_,\[Zeta]1nf_]:=-(Pnf^2/4)-Qnf^2/4+vpnf/2+(2 d\[Zeta]dtf)/(rnf^(3/2) \[Alpha]nf)+(2 \[Alpha]1nf)/(rnf \[Alpha]nf)+(8 d\[Zeta]dtf Qnf w1nf \[Alpha]c)/(rnf^(5/2) \[Alpha]nf)+(8 Qnf w1nf \[Alpha]1nf \[Alpha]c)/(rnf^2 \[Alpha]nf)+(Qnf w1nf \[Beta]c)/rnf-1/2 Pnf^2 w2nf \[Beta]c-(dpdtf w1nf \[Beta]c)/(2 \[Alpha]nf)+(d\[Zeta]dtf wnf \[Beta]c)/(rnf^(3/2) \[Alpha]nf)+(Qnf w1nf \[Alpha]1nf \[Beta]c)/(2 \[Alpha]nf)+(wnf \[Alpha]1nf \[Beta]c)/(rnf \[Alpha]nf)+(8 d\[Zeta]dtf Pnf w1nf \[Alpha]c \[Zeta]nf)/(rnf^3 \[Alpha]nf)+(8 Pnf w1nf \[Alpha]1nf \[Alpha]c \[Zeta]nf)/(rnf^(5/2) \[Alpha]nf)+(Pnf w1nf \[Beta]c \[Zeta]nf)/rnf^(3/2)+(P1nf w1nf \[Beta]c \[Zeta]nf)/(2 Sqrt[rnf])-(2 \[Zeta]1nf \[Zeta]nf)/rnf^2-(8 Qnf w1nf \[Alpha]c \[Zeta]1nf \[Zeta]nf)/rnf^3-(wnf \[Beta]c \[Zeta]1nf \[Zeta]nf)/rnf^2+(4 Qnf w1nf \[Alpha]c \[Zeta]nf^2)/rnf^4+(4 Pnf^2 w2nf \[Alpha]c \[Zeta]nf^2)/rnf^3+(4 dpdtf w1nf \[Alpha]c \[Zeta]nf^2)/(rnf^3 \[Alpha]nf)-(4 Qnf w1nf \[Alpha]1nf \[Alpha]c \[Zeta]nf^2)/(rnf^3 \[Alpha]nf)-(8 Pnf w1nf \[Alpha]c \[Zeta]1nf \[Zeta]nf^2)/rnf^(7/2)+(4 Pnf w1nf \[Alpha]c \[Zeta]nf^3)/rnf^(9/2)-(4 P1nf w1nf \[Alpha]c \[Zeta]nf^3)/rnf^(7/2)


(*d*)Rnu[d\[Zeta]dtf_,rnf_,\[Alpha]nf_,\[Alpha]1nf_,\[Zeta]nf_]:=(2 \[Alpha]nf (\[Alpha]1nf (Sqrt[rnf]+\[Zeta]nf)^2+Sqrt[rnf] d\[Zeta]dtf))/rnf^2


printpart:=Block[{},{
xdM=xgrids/Mass;
 constraintze=constraint\[Zeta][Pn[[1;;-2]],P1n[[1;;-2]],Qn[[1;;-2]],rn[[1;;-2]],wn[[1;;-2]],w1n[[1;;-2]],w2n[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];
eomrr=EOMrr[dpdt,d\[Zeta]dt,Pn[[1;;-2]],P1n[[1;;-2]],Qn[[1;;-2]],rn[[1;;-2]],vpn[[1;;-2]],wn[[1;;-2]],w1n[[1;;-2]],w2n[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Zeta]n[[1;;-2]],\[Zeta]1n[[1;;-2]]];
rnuv=Rnu[d\[Zeta]dt,rn[[1;;-2]],\[Alpha]n[[1;;-2]],\[Alpha]1n[[1;;-2]],\[Zeta]n[[1;;-2]]];
(*\[Phi]zero[\[Phi]n];horizon[\[Zeta]n];*)
chargen=\[Phi]n[[-50;;-2]]rn[[-50;;-2]];Print[ListLinePlot[Transpose[{xdM,\[Zeta]n/rn^(1/2)}],PlotRange->All,AxesLabel->{x/M,\[Zeta]}]];
Print[ListLinePlot[Transpose[{xdM,\[Phi]n}],PlotRange->All,AxesLabel->{x/M,\[Phi]}]];
Print[ListLinePlot[Transpose[{xdM[[-50;;-2]],chargen}],PlotRange->All,AxesLabel->{x/M,SQ}]];
Print[ListLinePlot[Transpose[{rn[[-50;;-2]],chargen}],PlotRange->All,AxesLabel->{"r/M",SQ}]];
Print[ListLinePlot[Transpose[{xdM,Pn}],PlotRange->All,AxesLabel->{x/M,P}]];
(*Print[ListLinePlot[Transpose[{xdM[[1;;-20]],Qn[[1;;-20]]}],PlotRange\[Rule]All]];
Print[ListLinePlot[Transpose[{xdM[[1;;-20]],\[Alpha]n[[1;;-20]]}],PlotRange\[Rule]All]];*)
Print[ListLinePlot[Transpose[{xdM[[1;;-2]],rnuv}],PlotRange->All,AxesLabel->{x/M,rnu}]];
Print[ListLinePlot[Transpose[{xdM[[1;;-2]],Abs[constraintze]}],PlotRange->All,AxesLabel->{x/M,zetaconstraint}]];
Print[ListLinePlot[Transpose[{xdM[[1;;-2]],eomrr}],PlotRange->All,AxesLabel->{x/M,err}]];
Print[ListLinePlot[Transpose[{xdM,mtotal}],PlotRange->All,AxesLabel->{x/M,m}]];}]


databag:=Block[{
},
{AppendTo[\[Phi]list,{{t,exc},\[Phi]n}];
AppendTo[\[Zeta]list,\[Zeta]n];
AppendTo[\[Alpha]list,\[Alpha]n];
AppendTo[chargelist,chargen];
 AppendTo[rnulist,rnuv];
AppendTo[eomrrlist,eomrr];
AppendTo[mlist,mtotal];
AppendTo[conzetalist,Abs[constraintze]];}]


dpdtdzetadt[Pnp_,P1np_,Qnp_,Q1np_,rnp_,vpnp_,vpdnp_,wnp_,w1np_,w2np_,\[Alpha]np_,\[Alpha]1np_,\[Phi]np_,\[Zeta]np_,\[Zeta]1np_]:=Block[{a1, a2, a3}, {
a1=denominater[Pnp[[1;;-2]],Qnp[[1;;-2]],Q1np[[1;;-2]],rnp[[1;;-2]],wnp[[1;;-2]],w1np[[1;;-2]],w2np[[1;;-2]],\[Alpha]np[[1;;-2]],\[Alpha]1np[[1;;-2]],\[Phi]np[[1;;-2]],\[Zeta]np[[1;;-2]],\[Zeta]1np[[1;;-2]]];
a2=eqdpdtnominater[Pnp[[1;;-2]],P1np[[1;;-2]],Qnp[[1;;-2]],Q1np[[1;;-2]],rnp[[1;;-2]],vpnp[[1;;-2]],vpdnp[[1;;-2]],wnp[[1;;-2]],w1np[[1;;-2]],w2np[[1;;-2]],\[Alpha]np[[1;;-2]],\[Alpha]1np[[1;;-2]],\[Phi]np[[1;;-2]],\[Zeta]np[[1;;-2]],\[Zeta]1np[[1;;-2]]];a3=eqd\[Zeta]dtnominater[Pnp[[1]],P1np[[1]],Qnp[[1]],Q1np[[1]],rnp[[1]],vpnp[[1]],vpdnp[[1]],wnp[[1]],w1np[[1]],w2np[[1]],\[Alpha]np[[1]],\[Alpha]1np[[1]],\[Phi]np[[1]],\[Zeta]np[[1]],\[Zeta]1np[[1]]];dpdt0=a1 a2;
d\[Zeta]dt0=a1[[1]] a3;}](*\:7ed9\:51fa\:521d\:59cb\:6761\:4ef6\:7684\:5bf9\:5e94\:503c\:ff0c\:5bf9\:5e94\:7684P\:548c\[Zeta]\:5bf9\:65f6\:95f4\:5bfc\:6570\:ff0c\:5b58\:50a8\:8d77\:6765\:51cf\:5c11\:91cd\:590d\:8ba1\:7b97*)
