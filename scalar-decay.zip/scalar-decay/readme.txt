Codes generating the far-from-equilibrium process of descalarization in the paper aXiv: 2208.07548.

The file "generating initial data" generates the static solution, so-called hairy black hole, to the concerning system.

The data of hairy black hole is saved in "initial data" as an input to the file "simulation".

Files "function" and "simulation" simulate the dynamical process.

If use the codes please cite the papaer aXiv: 2208.07548.

%\cite{Liu:2022fxy}
\bibitem{Liu:2022fxy}
Y.~Liu, C.~Y.~Zhang, Q.~Chen, Z.~Cao, Y.~Tian and B.~Wang,
%``The critical scalarization and descalarization of black holes in a generalized scalar-tensor theory,''
[arXiv:2208.07548 [gr-qc]].
%5 citations counted in INSPIRE as of 16 Jan 2023